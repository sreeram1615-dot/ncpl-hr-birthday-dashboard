import React, { useState, useRef, useEffect } from 'react';
import { motion } from 'motion/react';
import { Users, Calendar, Settings, Bell, Upload, Video, Image as ImageIcon, MessageSquare, Loader2, CheckCircle2, X, Mail, Plus, Edit, Trash2, Play, Pause, Volume2, VolumeX, LogOut, UserCheck, User as UserIcon } from 'lucide-react';
import { format, isToday, isTomorrow, addDays } from 'date-fns';
import { Toaster } from '@/components/ui/sonner';
import { toast } from 'sonner';
import html2canvas from 'html2canvas';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Checkbox } from '@/components/ui/checkbox';

import { 
  generateBirthdayAssets, 
  generateBirthdayText, 
  generateBirthdayImage, 
  generateBirthdayVideo, 
  generateBirthdayMusic 
} from '@/src/services/geminiService';

import { db, auth } from './firebase';
import { signInWithPopup, GoogleAuthProvider, onAuthStateChanged, signOut, User } from 'firebase/auth';
import { collection, doc, setDoc, deleteDoc, onSnapshot, getDocFromServer } from 'firebase/firestore';
import { set as idbSet, get as idbGet, del as idbDel } from 'idb-keyval';

declare global {
  interface Window {
    aistudio?: {
      hasSelectedApiKey: () => Promise<boolean>;
      openSelectKey: () => Promise<void>;
    };
  }
}

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData.map(provider => ({
        providerId: provider.providerId,
        displayName: provider.displayName,
        email: provider.email,
        photoUrl: provider.photoURL
      })) || []
    },
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Initial Mock Employee Data
const getNextBirthday = (birthdateStr: string) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const bdate = new Date(birthdateStr);
  const nextBday = new Date(today.getFullYear(), bdate.getMonth(), bdate.getDate());
  if (nextBday < today) {
    nextBday.setFullYear(today.getFullYear() + 1);
  }
  return nextBday;
};

const isBirthdayTomorrow = (birthdateStr: string) => {
  const nextBday = getNextBirthday(birthdateStr);
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(0, 0, 0, 0);
  return nextBday.getTime() === tomorrow.getTime();
};

const isBirthdayThisMonth = (birthdateStr: string) => {
  const nextBday = getNextBirthday(birthdateStr);
  const today = new Date();
  return nextBday.getMonth() === today.getMonth() && nextBday.getFullYear() === today.getFullYear();
};

const INITIAL_EMPLOYEES = [
  { id: '6', name: 'Sushma Kandregula', department: 'Management', seniority: 'Executive', birthdate: addDays(new Date(), 1).toISOString(), avatar: 'https://i.pravatar.cc/150?u=sushma' },
  { id: '1', name: 'Sarah Jenkins', department: 'Engineering', seniority: 'Senior', birthdate: addDays(new Date(), 2).toISOString(), avatar: 'https://i.pravatar.cc/150?u=sarah' },
  { id: '2', name: 'Michael Chen', department: 'Marketing', seniority: 'Manager', birthdate: addDays(new Date(), 3).toISOString(), avatar: 'https://i.pravatar.cc/150?u=michael' },
  { id: '3', name: 'Emily Rodriguez', department: 'Sales', seniority: 'Associate', birthdate: addDays(new Date(), 5).toISOString(), avatar: 'https://i.pravatar.cc/150?u=emily' },
  { id: '4', name: 'David Kim', department: 'Design', seniority: 'Lead', birthdate: addDays(new Date(), 12).toISOString(), avatar: 'https://i.pravatar.cc/150?u=david' },
  { id: '5', name: 'Jessica Taylor', department: 'HR', seniority: 'Director', birthdate: addDays(new Date(), 15).toISOString(), avatar: 'https://i.pravatar.cc/150?u=jessica' },
];

type Employee = typeof INITIAL_EMPLOYEES[0] & {
  uploadedPhotos?: string[];
  uploadedLogo?: string | null;
  externalVideoUrl?: string | null;
  generatedAssets?: any;
  uid?: string;
  email?: string;
  whatsapp?: string;
};

const MUSIC_OPTIONS = [
  { id: 'upbeat-corporate', name: 'Upbeat Corporate' },
  { id: 'cheerful-acoustic', name: 'Cheerful Acoustic' },
  { id: 'energetic-pop', name: 'Energetic Pop' },
  { id: 'warm-piano', name: 'Warm Piano' },
];

export default function App() {
  const [currentView, setCurrentView] = useState<'birthdays' | 'directory' | 'settings'>('birthdays');
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [employees, setEmployees] = useState<Employee[]>([]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    async function testConnection() {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if(error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. ");
        }
      }
    }
    testConnection();
  }, []);

  useEffect(() => {
    if (!isAuthReady || !user) return;

    const unsubscribe = onSnapshot(collection(db, 'employees'), (snapshot) => {
      const emps: Employee[] = [];
      snapshot.docs.forEach(doc => {
        emps.push({ id: doc.id, ...doc.data() } as Employee);
      });
      setEmployees(emps);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, 'employees');
    });

    return () => unsubscribe();
  }, [isAuthReady, user]);

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Login failed", error);
      toast.error("Failed to log in.");
    }
  };

  const handleLogout = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Logout failed", error);
    }
  };

  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [selectedDepartment, setSelectedDepartment] = useState<string>('All');
  
  const departments = ['All', ...Array.from(new Set(employees.map(e => e.department)))];
  const filteredDirectoryEmployees = employees.filter(e => selectedDepartment === 'All' || e.department === selectedDepartment);
  
  // Employee CRUD State
  const [isEmployeeFormOpen, setIsEmployeeFormOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);
  const [employeeFormData, setEmployeeFormData] = useState({ name: '', department: '', seniority: '', birthdate: '', email: '', whatsapp: '', avatar: '' });
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [uploadedPhotos, setUploadedPhotos] = useState<string[]>([]);
  const [uploadedLogo, setUploadedLogo] = useState<string | null>(null);
  const [externalVideoUrl, setExternalVideoUrl] = useState<string | null>(null);
  const [selectedMusic, setSelectedMusic] = useState(MUSIC_OPTIONS[0].id);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
  const [sendWhatsApp, setSendWhatsApp] = useState(true);
  const [sendEmail, setSendEmail] = useState(true);
  const [emailScheduleDate, setEmailScheduleDate] = useState('');
  const [emailScheduleTime, setEmailScheduleTime] = useState('');
  const flyerRef = useRef<HTMLDivElement>(null);
  
  const [flyerPhotoIndex, setFlyerPhotoIndex] = useState(0);
  const [flyerStyleIndex, setFlyerStyleIndex] = useState(0);
  const [flyerAlignIndex, setFlyerAlignIndex] = useState(0);
  
  const FLYER_STYLES = [
    { bg: 'from-black/20 via-transparent to-white/90', text: 'text-blue-900', pText: 'text-slate-700', border: 'border-white', label: "Classic Bright" },
    { bg: 'from-purple-900/40 via-purple-900/10 to-indigo-950/90', text: 'text-white', pText: 'text-purple-100', border: 'border-purple-300', label: "Midnight Glow" },
    { bg: 'from-amber-500/20 via-orange-100/30 to-amber-50/95', text: 'text-amber-900', pText: 'text-amber-800', border: 'border-amber-200', label: "Warm Sunset" },
    { bg: 'from-emerald-900/30 via-transparent to-emerald-50/95', text: 'text-emerald-950', pText: 'text-emerald-800', border: 'border-emerald-200', label: "Fresh Green" }
  ];

  const FLYER_ALIGNS = [
    { container: 'items-center text-center', textWrap: 'max-w-xs text-center', justify: 'justify-center', label: 'Center Focus' },
    { container: 'items-start text-left', textWrap: 'max-w-xs text-left', justify: 'justify-end', label: 'Classic Left' },
    { container: 'items-end text-right', textWrap: 'max-w-xs text-right', justify: 'justify-end', label: 'Modern Right' },
  ];

  const [showSuccessConfirmation, setShowSuccessConfirmation] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [generatedAssets, setGeneratedAssets] = useState<{
    videoDescription: string;
    flyerHeadline: string;
    flyerMessage: string;
    flyerBackgroundImagePrompt?: string;
    whatsappReminder: string;
    emailReminderSubject: string;
    emailReminderBody: string;
    videoUrl?: string;
    imageUrl?: string;
    musicUrl?: string;
  } | null>(null);

  const isScheduleInPast = () => {
    if (!emailScheduleDate || !emailScheduleTime) return false;
    try {
      const [year, month, day] = emailScheduleDate.split('-').map(Number);
      const [hours, minutes] = emailScheduleTime.split(':').map(Number);
      const scheduledDate = new Date(year, month - 1, day, hours, minutes);
      return scheduledDate < new Date();
    } catch (e) {
      return false;
    }
  };

  const ensureApiKey = async () => {
    if (window.aistudio?.hasSelectedApiKey && window.aistudio?.openSelectKey) {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      if (!hasKey) {
        await window.aistudio.openSelectKey();
      }
    }
  };

  // Video Player State
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(100);
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [hoverProgress, setHoverProgress] = useState<number | null>(null);
  const [videoProgress, setVideoProgress] = useState(0);
  const [currentFrame, setCurrentFrame] = useState(0);
  
  const [videoPrimaryText, setVideoPrimaryText] = useState('');
  const [videoSecondaryText, setVideoSecondaryText] = useState('Thank you for being an important part of our team');
  const [videoAnimationStyle, setVideoAnimationStyle] = useState('fade');
  const [videoAspectRatio, setVideoAspectRatio] = useState<"16:9" | "9:16">("9:16");
  const [videoSelectedPhotos, setVideoSelectedPhotos] = useState<number[]>([]);
  
  const [imageAspectRatio, setImageAspectRatio] = useState<"1:1" | "3:4" | "4:3" | "9:16" | "16:9" | "2:3" | "3:2" | "21:9">("1:1");
  const [imageSize, setImageSize] = useState<"1K" | "2K" | "4K">("1K");
  const [imagePrompt, setImagePrompt] = useState("");
  const [isGeneratingImage, setIsGeneratingImage] = useState(false);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  
  const [musicDuration, setMusicDuration] = useState<"short" | "full">("short");
  const [musicPrompt, setMusicPrompt] = useState("");
  const [isGeneratingMusic, setIsGeneratingMusic] = useState(false);
  const [generatedMusicUrl, setGeneratedMusicUrl] = useState<string | null>(null);
  
  const [thinkingMode, setThinkingMode] = useState(false);
  const [isGeneratingVideoAI, setIsGeneratingVideoAI] = useState(false);
  const [generatedVideoUrl, setGeneratedVideoUrl] = useState<string | null>(null);
  const [mainPersonPhotoIndex, setMainPersonPhotoIndex] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isPlaying) {
      interval = setInterval(() => {
        setVideoProgress(p => {
          if (p >= 100) {
            setIsPlaying(false);
            return 0;
          }
          return p + 0.333; // ~30 seconds total
        });
      }, 100 / playbackSpeed);
    }
    return () => clearInterval(interval);
  }, [isPlaying, playbackSpeed]);

  useEffect(() => {
    if (isPlaying) {
      // Change frame every 33% (approx 3.3 seconds)
      const selectedPhotosUrls = videoSelectedPhotos.map(i => uploadedPhotos[i]).filter(Boolean);
      const imagesToLoad = selectedPhotosUrls.length > 0 ? selectedPhotosUrls : uploadedPhotos;
      setCurrentFrame(Math.floor(videoProgress / 34) % Math.max(1, imagesToLoad.length));
    } else {
      setCurrentFrame(0);
      setVideoProgress(0);
    }
  }, [videoProgress, isPlaying, uploadedPhotos, videoSelectedPhotos]);

  useEffect(() => {
    if (selectedEmployee && user) {
      const updateEmployee = async () => {
        try {
          const empRef = doc(db, 'employees', selectedEmployee.id);
          await setDoc(empRef, {
            name: selectedEmployee.name,
            department: selectedEmployee.department,
            seniority: selectedEmployee.seniority || 'Staff',
            birthdate: selectedEmployee.birthdate,
            avatar: selectedEmployee.avatar || `https://i.pravatar.cc/150?u=${encodeURIComponent(selectedEmployee.name)}`,
            uid: selectedEmployee.uid || user.uid,
            uploadedPhotos,
            uploadedLogo,
            externalVideoUrl,
            generatedAssets,
          }, { merge: true });
        } catch (error) {
          handleFirestoreError(error, OperationType.UPDATE, `employees/${selectedEmployee.id}`);
        }
      };

      // Simple check to prevent unnecessary writes if nothing changed
      if (
        JSON.stringify(uploadedPhotos) !== JSON.stringify(selectedEmployee.uploadedPhotos) ||
        uploadedLogo !== selectedEmployee.uploadedLogo ||
        externalVideoUrl !== selectedEmployee.externalVideoUrl ||
        JSON.stringify(generatedAssets) !== JSON.stringify(selectedEmployee.generatedAssets)
      ) {
        updateEmployee();
      }
    }
  }, [uploadedPhotos, uploadedLogo, externalVideoUrl, generatedAssets, selectedEmployee, user]);

  const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 800;
          const MAX_HEIGHT = 800;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          resolve(canvas.toDataURL('image/jpeg', 0.7));
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files) as File[];
      
      for (const file of files) {
        try {
          const compressed = await compressImage(file);
          setUploadedPhotos(prev => {
            const newPhotos = [...prev, compressed];
            const sliced = newPhotos.slice(0, 4); // Max 4 photos
            setVideoSelectedPhotos(prevSelected => {
              const newIndex = sliced.length - 1;
              return prevSelected.includes(newIndex) ? prevSelected : [...prevSelected, newIndex];
            });
            return sliced;
          });
        } catch (error) {
          console.error("Error compressing image", error);
        }
      }
    }
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      try {
        const compressed = await compressImage(e.target.files[0]);
        setUploadedLogo(compressed);
      } catch (error) {
        console.error("Error compressing logo", error);
      }
    }
  };

  const removePhoto = (indexToRemove: number) => {
    setUploadedPhotos(prev => prev.filter((_, index) => index !== indexToRemove));
    setVideoSelectedPhotos(prev => prev.filter(i => i !== indexToRemove).map(i => i > indexToRemove ? i - 1 : i));
  };

  const removeLogo = () => {
    setUploadedLogo(null);
  };

  const handleExternalVideoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0] && selectedEmployee) {
      const file = e.target.files[0];
      const url = URL.createObjectURL(file);
      setExternalVideoUrl(url);
      setGeneratedVideoUrl(null); // Prioritize the uploaded video over any previously AI-generated one
      
      try {
        await idbSet(`externalVideo_${selectedEmployee.id}`, file);
        toast.success(`Pre-made video successfully attached and securely stored for ${selectedEmployee.name}!`);
      } catch (err) {
        console.error(err);
        toast.error('Failed to save the external video locally.');
      }
    }
  };

  const removeExternalVideo = async () => {
    setExternalVideoUrl(null);
    if (selectedEmployee) {
      try {
        await idbDel(`externalVideo_${selectedEmployee.id}`);
      } catch(err) {}
    }
  };

  const handleGenerate = async () => {
    if (!selectedEmployee) return;
    if (uploadedPhotos.length < 1) {
      toast.error('Please upload at least 1 photo for the celebration.');
      return;
    }

    try {
      await ensureApiKey();
    } catch (e) {
      console.error(e);
      toast.error('Failed to get API key.');
      return;
    }

    setIsGenerating(true);
    try {
      const seniority = selectedEmployee.seniority || 'Staff';
      // 1. Generate text assets (headlines, messages)
      const textAssets = await generateBirthdayText(selectedEmployee.name, selectedEmployee.department, seniority);
      
      // 2. Generate initial image for flyer
      const imageUrl = await generateBirthdayImage(
        `A professional yet festive birthday background for ${selectedEmployee.name}, who is a ${seniority} in the ${selectedEmployee.department} department. Office celebration style, soft lighting`,
        imageAspectRatio,
        imageSize,
        uploadedLogo
      );

      // 3. Generate video
      const videoPrompt = `Create a realistic cinematic birthday video for ${selectedEmployee.name}. 
      Style: ${videoAnimationStyle}. 
      Input photos provided. 
      Theme: Office celebration, joyful team members, birthday cake with candles.`;
      
      // We'll trigger video generation separately or part of this? 
      // User said "Animate images into video", implying we should send photos to Veo.
      // The generateBirthdayVideo function in geminiService doesn't accept images yet.
      // I'll update geminiService to handle image-to-video if needed, but for now I'll use text-to-video as a base
      // and maybe add image inputs to the service.
      
      const musicPrompt = `Upbeat, joyful acoustic birthday background music for ${selectedEmployee.name}`;
      const musicUrl = await generateBirthdayMusic(musicPrompt, musicDuration);

      const assets = {
        ...textAssets,
        videoDescription: videoPrompt,
        flyerBackgroundImagePrompt: videoPrompt,
        imageUrl,
        musicUrl
      };

      setGeneratedAssets(assets);
      setGeneratedImageUrl(imageUrl);
      setGeneratedMusicUrl(musicUrl);
      
      toast.success('Assets generated successfully!');
    } catch (error) {
      toast.error('Failed to generate assets. Please check your API key.');
      console.error(error);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateVideoAI = async () => {
    if (!selectedEmployee) return;

    try {
      await ensureApiKey();
    } catch (e) {
      console.error(e);
      toast.error('Failed to get API key.');
      return;
    }

    setIsGeneratingVideoAI(true);
    try {
      // Constructing a hyper-specified prompt for Veo 3.1 based on the reference video
      const strictRoleGuidelines = `
        🎬 CINEMATIC BIRTHDAY VIDEO STRUCTURE (4 SCENES)
        
        Scene 1 (Start - 8s): 
        - Visual: A diverse group of joyful employees in a modern office conference room.
        - Atmosphere: Balloons and falling confetti everywhere.
        - Text Overlay: "Your Team Celebrates"
        
        Scene 2 (8s - 15s):
        - Visual: A high-quality professional portrait of ${selectedEmployee.name}.
        - Atmosphere: Warm, soft lighting, smiling naturally.
        - MUST be generated based on the face from the provided main photo.
        - Text Overlay: "Happy Birthday ${selectedEmployee.name}"
        
        Scene 3 (15s - 24s):
        - Visual: Extreme close-up of a delicious birthday cake with glowing candles flickering on an office table.
        - Atmosphere: Cinematic depth of field, festive decor in the blurred background.
        - Text Overlay: "Wishing You Joy & Success"
        
        Scene 4 (24s - End):
        - Visual: Coworkers clapping enthusiastically as ${selectedEmployee.name} holds the cake in the center.
        - Atmosphere: Genuine team bonding and celebration, corporate warmth.
        - Text Overlay: "Thank you for being an important part of our team"

        🎯 TECHNICAL STYLE
        - Cinematic lighting, smooth camera pans, high realism, professional transitions.
        - Ensure text is clearly legible against backgrounds.
      `;

      const videoUrl = await generateBirthdayVideo(
        strictRoleGuidelines,
        videoAspectRatio
      );
      
      // Also generate the corporate music specifically requested
      const musicUrl = await generateBirthdayMusic("Upbeat Corporate Happy Birthday instrumental", musicDuration);
      
      setGeneratedVideoUrl(videoUrl);
      setGeneratedMusicUrl(musicUrl);
      setGeneratedAssets(prev => prev ? { ...prev, videoUrl, musicUrl } : null);
      toast.success('Cinematic birthday celebration generated!');
    } catch (error) {
      toast.error('Failed to generate high-quality video.');
      console.error(error);
    } finally {
      setIsGeneratingVideoAI(false);
    }
  };

  const handleEditImageAI = async () => {
    if (!generatedImageUrl) return;

    try {
      await ensureApiKey();
    } catch (e) {
      console.error(e);
      toast.error('Failed to get API key.');
      return;
    }

    setIsGeneratingImage(true);
    try {
      const newImageUrl = await generateBirthdayImage(
        imagePrompt || "Enhance the birthday decorations, add more colorful balloons",
        imageAspectRatio,
        imageSize
      );
      setGeneratedImageUrl(newImageUrl);
      setGeneratedAssets(prev => prev ? { ...prev, imageUrl: newImageUrl } : null);
      toast.success('Image edited successfully!');
    } catch (error) {
      toast.error('Failed to edit image.');
      console.error(error);
    } finally {
      setIsGeneratingImage(false);
    }
  };

  const handleGenerateCustomMusic = async () => {
    if (!musicPrompt) {
      toast.error('Please describe the music you want.');
      return;
    }

    try {
      await ensureApiKey();
    } catch (e) {
      console.error(e);
      toast.error('Failed to get API key.');
      return;
    }

    setIsGeneratingMusic(true);
    try {
      const musicUrl = await generateBirthdayMusic(musicPrompt, musicDuration);
      setGeneratedMusicUrl(musicUrl);
      if (generatedAssets) {
          setGeneratedAssets({ ...generatedAssets, musicUrl });
      }
      toast.success('Custom music generated!');
    } catch (error) {
      toast.error('Failed to generate music.');
      console.error(error);
    } finally {
      setIsGeneratingMusic(false);
    }
  };

  const resetState = () => {
    setUploadedPhotos([]);
    setUploadedLogo(null);
    setExternalVideoUrl(null);
    setGeneratedAssets(null);
    setGeneratedImageUrl(null);
    setGeneratedVideoUrl(null);
    setGeneratedMusicUrl(null);
    setShowSuccessConfirmation(false);
    setSuccessMessage('');
    setFlyerPhotoIndex(0);
    setFlyerStyleIndex(0);
  };

  const openEmployeeDialog = (employee: Employee) => {
    setSelectedEmployee(employee);
    setUploadedPhotos(employee.uploadedPhotos || []);
    setUploadedLogo(employee.uploadedLogo || null);
    setExternalVideoUrl(employee.externalVideoUrl || null);
    setGeneratedAssets(employee.generatedAssets || null);
    
    setGeneratedImageUrl(employee.generatedAssets?.imageUrl || null);
    setGeneratedMusicUrl(employee.generatedAssets?.musicUrl || null);
    setGeneratedVideoUrl(employee.generatedAssets?.videoUrl || employee.externalVideoUrl || null);

    setShowSuccessConfirmation(false);
    setSuccessMessage('');
    setFlyerPhotoIndex(0);
    setFlyerStyleIndex(Math.floor(Math.random() * FLYER_STYLES.length)); // Randomize default for uniqueness!
    setFlyerAlignIndex(Math.floor(Math.random() * FLYER_ALIGNS.length));
    
    setVideoPrimaryText(`Happy Birthday ${employee.name}!`);
    setVideoSecondaryText('Thank you for being an important part of our team');
    setVideoAnimationStyle('fade');
    setVideoSelectedPhotos(employee.uploadedPhotos ? employee.uploadedPhotos.map((_, i) => i) : []);
    
    // Default schedule: 11 PM the night before
    const bdate = new Date(employee.birthdate);
    const nightBefore = new Date(bdate);
    nightBefore.setDate(nightBefore.getDate() - 1);
    setEmailScheduleDate(format(nightBefore, 'yyyy-MM-dd'));
    setEmailScheduleTime('23:00');

    setIsDialogOpen(true);
  };

  useEffect(() => {
    // Attempt to hydrate external video properly from IndexedDB when selecting employee
    if (selectedEmployee) {
      idbGet(`externalVideo_${selectedEmployee.id}`).then((storedFile) => {
        if (storedFile instanceof File || storedFile instanceof Blob) {
           const url = URL.createObjectURL(storedFile);
           setExternalVideoUrl(url);
           // Update actual player instance if AI generated nothing
           if (!generatedVideoUrl) {
              setGeneratedVideoUrl(null); 
           }
        }
      }).catch(err => {
         console.warn("Could not retrieve stored local video.", err);
      });
    }
  }, [selectedEmployee?.id]);

  const handleOpenAddEmployee = () => {
    setEditingEmployee(null);
    setEmployeeFormData({ name: '', department: '', seniority: '', birthdate: format(new Date(), 'yyyy-MM-dd'), email: '', whatsapp: '', avatar: '' });
    setIsEmployeeFormOpen(true);
  };

  const handleOpenEditEmployee = (employee: Employee) => {
    setEditingEmployee(employee);
    setEmployeeFormData({ 
      name: employee.name, 
      department: employee.department, 
      seniority: employee.seniority || '',
      birthdate: format(new Date(employee.birthdate), 'yyyy-MM-dd'),
      email: employee.email || '',
      whatsapp: employee.whatsapp || '',
      avatar: employee.avatar || ''
    });
    setIsEmployeeFormOpen(true);
  };

  const handleDeleteEmployee = async (id: string) => {
    try {
      await deleteDoc(doc(db, 'employees', id));
      toast.success('Employee deleted successfully.');
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `employees/${id}`);
    }
  };

  const handleAvatarUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          setEmployeeFormData(prev => ({ ...prev, avatar: event.target!.result as string }));
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveEmployee = async () => {
    if (!user) {
      toast.error('You must be logged in to save an employee.');
      return;
    }

    if (!employeeFormData.name || !employeeFormData.department || !employeeFormData.birthdate) {
      toast.error('Please fill in Name, Department and Birthdate.');
      return;
    }

    if (employeeFormData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(employeeFormData.email)) {
      toast.error('Please enter a valid email address.');
      return;
    }

    if (employeeFormData.whatsapp) {
      const cleanWhatsapp = employeeFormData.whatsapp.replace(/\D/g, '');
      if (cleanWhatsapp.length < 10 || cleanWhatsapp.length > 15) {
        toast.error('Please enter a valid WhatsApp number (10-15 digits).');
        return;
      }
    }

    const birthdateIso = new Date(employeeFormData.birthdate).toISOString();

    try {
      if (editingEmployee) {
        const empRef = doc(db, 'employees', editingEmployee.id);
        await setDoc(empRef, {
          name: employeeFormData.name,
          department: employeeFormData.department,
          seniority: employeeFormData.seniority || 'Staff',
          birthdate: birthdateIso,
          email: employeeFormData.email,
          whatsapp: employeeFormData.whatsapp,
          ...(employeeFormData.avatar ? { avatar: employeeFormData.avatar } : {}),
        }, { merge: true });
        toast.success('Employee updated successfully.');
      } else {
        const newId = Math.random().toString(36).substr(2, 9);
        const empRef = doc(db, 'employees', newId);
        await setDoc(empRef, {
          name: employeeFormData.name,
          department: employeeFormData.department,
          seniority: employeeFormData.seniority || 'Staff',
          birthdate: birthdateIso,
          email: employeeFormData.email,
          whatsapp: employeeFormData.whatsapp,
          avatar: employeeFormData.avatar || `https://i.pravatar.cc/150?u=${encodeURIComponent(employeeFormData.name)}`,
          uid: user.uid,
        });
        toast.success('Employee added successfully.');
      }
      setIsEmployeeFormOpen(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'employees');
    }
  };

  const handleDownloadVideo = async () => {
    if (!selectedEmployee || !generatedAssets) return;
    
    // If a real video file URL already exists (pre-made or external), download it directly
    const actualVideoUrl = generatedVideoUrl || externalVideoUrl;
    if (actualVideoUrl && actualVideoUrl.startsWith('blob:')) {
      const a = document.createElement('a');
      a.href = actualVideoUrl;
      a.download = `${selectedEmployee.name.replace(/\s+/g, '_')}_Birthday_Video.mp4`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      toast.success('Video downloaded successfully!');
      return;
    } else if (actualVideoUrl) {
      // For cross-origin or standard URLs, we might just open it
      const a = document.createElement('a');
      a.href = actualVideoUrl;
      a.target = '_blank';
      a.download = `${selectedEmployee.name.replace(/\s+/g, '_')}_Birthday_Video.mp4`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      toast.success('Opened video for download!');
      return;
    }

    setIsGeneratingVideo(true);
    toast.info('Generating visual video file, please wait...');

    try {
      const canvas = document.createElement('canvas');
      canvas.width = 1280;
      canvas.height = 720;
      // Append to DOM to ensure captureStream works in all browsers
      canvas.style.position = 'absolute';
      canvas.style.opacity = '0';
      canvas.style.pointerEvents = 'none';
      document.body.appendChild(canvas);

      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Could not get canvas context');

      // Check supported mime types
      let mimeType = '';
      if (MediaRecorder.isTypeSupported('video/mp4')) {
        mimeType = 'video/mp4';
      } else if (MediaRecorder.isTypeSupported('video/webm;codecs=vp9')) {
        mimeType = 'video/webm;codecs=vp9';
      } else if (MediaRecorder.isTypeSupported('video/webm')) {
        mimeType = 'video/webm';
      } else {
        mimeType = '';
      }

      const stream = canvas.captureStream(30);
      const recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      const chunks: BlobPart[] = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };
      
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: mimeType || 'video/mp4' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${selectedEmployee.name.replace(/\s+/g, '_')}_Birthday_Video.mp4`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        document.body.removeChild(canvas);
        setIsGeneratingVideo(false);
        toast.success('Video downloaded successfully!');
      };

      recorder.start();

      // Animation loop
      let frame = 0;
      const totalFrames = 150; // 5 seconds at 30fps
      
      // Pre-load images
      const selectedPhotosUrls = videoSelectedPhotos.map(i => uploadedPhotos[i]).filter(Boolean);
      const imagesToLoad = selectedPhotosUrls.length > 0 ? selectedPhotosUrls : uploadedPhotos;
      
      const images = await Promise.all(imagesToLoad.map(src => {
        return new Promise<HTMLImageElement>((resolve) => {
          const img = new Image();
          img.crossOrigin = 'anonymous';
          img.onload = () => resolve(img);
          img.onerror = () => resolve(img); // resolve anyway to not block
          img.src = src;
        });
      }));

      const drawFrame = () => {
        if (frame >= totalFrames) {
          // Add a small delay before stopping to ensure the last frame is captured
          setTimeout(() => recorder.stop(), 100);
          return;
        }

        // Draw background
        // 🎉 Party Gradient Background
const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
gradient.addColorStop(0, "#1e3a8a");
gradient.addColorStop(1, "#9333ea");

ctx.fillStyle = gradient;
ctx.fillRect(0, 0, canvas.width, canvas.height);

// 🎊 Confetti Effect
for (let i = 0; i < 40; i++) {
  ctx.fillStyle = `hsl(${Math.random()*360}, 80%, 60%)`;
  ctx.beginPath();
  ctx.arc(Math.random()*canvas.width, Math.random()*canvas.height, 3, 0, Math.PI*2);
  ctx.fill();
}
const cakeImg = new Image();
cakeImg.src = "https://cdn-icons-png.flaticon.com/512/3468/3468379.png";

if (cakeImg.complete) {
  ctx.drawImage(
    cakeImg,
    canvas.width / 2 - 80,
    canvas.height / 2 + 140,
    160,
    160
  );
}
uploadedPhotos.slice(1, 4).forEach((src, index) => {
  const img = new Image();
  img.src = src;

  if (img.complete) {
    const positions = [
      [canvas.width / 2 - 300, canvas.height / 2],
      [canvas.width / 2 + 200, canvas.height / 2],
      [canvas.width / 2 - 50, canvas.height / 2 - 200],
    ];

    const [x, y] = positions[index];

    ctx.save();
    ctx.beginPath();
    ctx.arc(x + 50, y + 50, 50, 0, Math.PI * 2);
    ctx.clip();

    ctx.drawImage(img, x, y, 100, 100);
    ctx.restore();
  }
});
        // Draw photo if available
        if (images.length > 0) {
          const imgIndex = Math.floor((frame / 30)) % images.length;
          const img = images[imgIndex];
          
          if (img.complete && img.naturalWidth > 0) {
            let scale = 1;
            let x = 0;
            let y = 0;
            let alpha = 0.6;
            
            if (videoAnimationStyle === 'zoom') {
              scale = 1 + (frame % 30) / 150;
              const w = canvas.width * scale;
              const h = canvas.height * scale;
              x = (canvas.width - w) / 2;
              y = (canvas.height - h) / 2;
            } else if (videoAnimationStyle === 'slide') {
              const slideProgress = (frame % 30) / 30;
              scale = 1.2;
              const w = canvas.width * scale;
              const h = canvas.height * scale;
              x = (canvas.width - w) / 2 - (slideProgress * 100) + 50;
              y = (canvas.height - h) / 2;
            } else {
              // fade
              const fadeProgress = (frame % 30) / 30;
              alpha = fadeProgress < 0.2 ? fadeProgress * 3 : fadeProgress > 0.8 ? (1 - fadeProgress) * 3 : 0.6;
              scale = 1.05;
              const w = canvas.width * scale;
              const h = canvas.height * scale;
              x = (canvas.width - w) / 2;
              y = (canvas.height - h) / 2;
            }
            
            ctx.globalAlpha = alpha;
            ctx.drawImage(img, x, y, canvas.width * scale, canvas.height * scale);
            ctx.globalAlpha = 1.0;
          }
        }

        // Draw text
        ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
        ctx.fillRect(0, 0, canvas.width, canvas.height);

        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        // Draw logo if available
        if (uploadedLogo) {
          const logoImg = new Image();
          logoImg.src = uploadedLogo;
          if (logoImg.complete && logoImg.naturalWidth > 0) {
            ctx.drawImage(logoImg, canvas.width - 120, canvas.height - 120, 80, 80);
          }
        }

        frame++;
        setTimeout(drawFrame, 1000 / 30); // 30fps
      };

      drawFrame();

    } catch (error) {
      console.error('Error generating video:', error);
      toast.error('Failed to generate video file.');
      setIsGeneratingVideo(false);
    }
  };

  const handleDownloadFlyer = async () => {
    if (!flyerRef.current || !selectedEmployee) return;
    
    try {
      const canvas = await html2canvas(flyerRef.current, {
        scale: 2, // Higher quality
        useCORS: true, // Allow external images like pravatar
        backgroundColor: null,
      });
      
      const image = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      link.href = image;
      link.download = `${selectedEmployee.name.replace(/\s+/g, '_')}_Birthday_Flyer.png`;
      link.click();
      
      toast.success('Flyer downloaded successfully!');
    } catch (error) {
      console.error('Error downloading flyer:', error);
      toast.error('Failed to download flyer.');
    }
  };

  const handleShareFlyer = () => {
    if (!generatedAssets || !selectedEmployee) return;
    
    const subject = encodeURIComponent(`Happy Birthday ${selectedEmployee.name}!`);
    const body = encodeURIComponent(`${generatedAssets.flyerHeadline}\n\n${generatedAssets.flyerMessage}`);
    const to = selectedEmployee.email ? selectedEmployee.email : '';
    
    window.location.href = `mailto:${to}?subject=${subject}&body=${body}`;
  };

  return (
    <div className="flex h-screen bg-[#F0F8FF] text-slate-900 font-sans selection:bg-blue-200">
      {/* Decorative Background Elements */}
      <div className="fixed top-0 left-0 w-full h-64 bg-gradient-to-b from-blue-500 to-transparent opacity-10 pointer-events-none z-0" />
      
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-blue-100 flex flex-col shadow-[4px_0_24px_rgba(0,0,0,0.02)] z-20 relative">
        <div className="p-6 border-b border-blue-50 flex items-center gap-3">
          <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-sm border border-slate-100 overflow-hidden shrink-0 relative">
            <img 
              src="https://media.licdn.com/dms/image/v2/C560BAQF2Ew-j_D-m_A/company-logo_200_200/company-logo_200_200/0/1630669280630/ncpl_inc_logo?e=2147483647&v=beta&t=Z_Z_Z_Z_Z_Z_Z_Z_Z_Z_Z_Z_Z_Z_Z_Z_Z_Z_Z_Z_Z_Z" 
              alt="NCPL Logo" 
              className="w-full h-full object-cover scale-[1.3] -translate-y-[15%]" 
              onError={(e) => {
                e.currentTarget.src = "https://ui-avatars.com/api/?name=NCPL&background=0D8ABC&color=fff";
              }} 
            />
          </div>
          <span className="font-black text-xl leading-tight tracking-tight text-blue-900">NCPL HR<br/><span className="text-sm text-blue-500 font-bold">Birthday Dashboard</span></span>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <button 
            onClick={() => setCurrentView('birthdays')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all duration-200 ${currentView === 'birthdays' ? 'bg-blue-500 text-white shadow-md shadow-blue-500/20 scale-[1.02]' : 'text-slate-500 hover:bg-blue-50 hover:text-blue-600'}`}
          >
            <Calendar className="w-5 h-5" />
            Upcoming Birthdays
          </button>
          <button 
            onClick={() => setCurrentView('directory')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all duration-200 ${currentView === 'directory' ? 'bg-blue-500 text-white shadow-md shadow-blue-500/20 scale-[1.02]' : 'text-slate-500 hover:bg-blue-50 hover:text-blue-600'}`}
          >
            <Users className="w-5 h-5" />
            Employee Directory
          </button>
          <button 
            onClick={() => setCurrentView('settings')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold transition-all duration-200 ${currentView === 'settings' ? 'bg-blue-500 text-white shadow-md shadow-blue-500/20 scale-[1.02]' : 'text-slate-500 hover:bg-blue-50 hover:text-blue-600'}`}
          >
            <Settings className="w-5 h-5" />
            Settings
          </button>
        </nav>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative z-10">
        <header className="h-20 bg-white/80 backdrop-blur-md border-b border-blue-100 flex items-center justify-between px-8 sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <h1 className="text-3xl font-black tracking-tight text-blue-900 flex items-center gap-2">
              {currentView === 'birthdays' ? '🎉 Upcoming Birthdays' : currentView === 'directory' ? '👥 Employee Directory' : '⚙️ Settings'}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="rounded-full hover:bg-blue-50 text-blue-600">
              <Bell className="w-5 h-5" />
            </Button>
            <div className="flex items-center gap-2 bg-white border border-blue-100 rounded-full pl-1 pr-4 py-1 shadow-sm">
              {user ? (
                <>
                  <div className="w-8 h-8 bg-blue-100 rounded-full overflow-hidden border-2 border-white shadow-sm">
                    <img src={user.photoURL || "https://i.pravatar.cc/150?u=admin"} alt={user.displayName || "User"} className="w-full h-full object-cover" />
                  </div>
                  <span className="text-sm font-bold text-slate-700 ml-1">{user.displayName || 'Admin'}</span>
                  <Button variant="ghost" size="icon" onClick={handleLogout} className="w-8 h-8 rounded-full text-slate-400 hover:text-red-500 hover:bg-red-50 ml-2" title="Logout">
                    <LogOut className="w-4 h-4" />
                  </Button>
                </>
              ) : (
                <Button variant="default" size="sm" onClick={handleLogin}>
                  Login
                </Button>
              )}
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-auto p-8 relative z-10">
          {currentView === 'birthdays' && (
            <div className="space-y-6 max-w-6xl mx-auto">
              {/* Hero Banner for Tomorrow's Birthday (if any) */}
              {employees.some(e => isBirthdayTomorrow(e.birthdate)) && (
                <div className="bg-gradient-to-r from-pink-500 to-rose-400 rounded-3xl p-8 text-white shadow-xl shadow-pink-500/20 flex items-center justify-between relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-10 rounded-full blur-3xl transform translate-x-1/2 -translate-y-1/2" />
                  <div className="relative z-10">
                    <h2 className="text-3xl font-black mb-2 flex items-center gap-3">
                      <span className="text-4xl">🎂</span> 
                      {employees.find(e => isBirthdayTomorrow(e.birthdate))?.name}'s birthday is tomorrow!
                    </h2>
                    <p className="text-pink-100 font-medium text-lg">Assets pending. Prepare them now to celebrate!</p>
                  </div>
                  <Button 
                    size="lg" 
                    className="relative z-10 bg-white text-pink-600 hover:bg-pink-50 font-bold rounded-full px-8 shadow-lg"
                    onClick={() => {
                      const tom = employees.find(e => isBirthdayTomorrow(e.birthdate));
                      if (tom) openEmployeeDialog(tom);
                    }}
                  >
                    Prepare Now
                  </Button>
                </div>
              )}

              {/* Stats Cards */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-pink-100 relative overflow-hidden group hover:shadow-md transition-all">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-pink-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
                  <div className="relative z-10">
                    <div className="text-5xl font-black text-pink-500 mb-2">{employees.filter(e => isBirthdayThisMonth(e.birthdate)).length}</div>
                    <div className="text-slate-700 font-bold text-lg">This month</div>
                    <div className="text-pink-400 text-sm font-medium mt-1">Upcoming celebrations</div>
                  </div>
                </div>
                
                <div className="bg-white rounded-3xl p-6 shadow-sm border border-blue-100 relative overflow-hidden group hover:shadow-md transition-all">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-blue-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
                  <div className="relative z-10">
                    <div className="text-5xl font-black text-blue-500 mb-2">{employees.filter(e => isBirthdayTomorrow(e.birthdate)).length}</div>
                    <div className="text-slate-700 font-bold text-lg">Tomorrow</div>
                    <div className="text-blue-400 text-sm font-medium mt-1">Needs attention</div>
                  </div>
                </div>

                <div className="bg-white rounded-3xl p-6 shadow-sm border border-green-100 relative overflow-hidden group hover:shadow-md transition-all">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-green-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
                  <div className="relative z-10">
                    <div className="text-5xl font-black text-green-500 mb-2">{employees.filter(e => e.generatedAssets && e.generatedAssets.videoDescription).length}</div>
                    <div className="text-slate-700 font-bold text-lg">Videos ready</div>
                    <div className="text-green-400 text-sm font-medium mt-1">Ready to send</div>
                  </div>
                </div>

                <div className="bg-white rounded-3xl p-6 shadow-sm border border-amber-100 relative overflow-hidden group hover:shadow-md transition-all">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-amber-50 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-110" />
                  <div className="relative z-10">
                    <div className="text-5xl font-black text-amber-500 mb-2">{employees.filter(e => e.generatedAssets && isBirthdayThisMonth(e.birthdate)).length}</div>
                    <div className="text-slate-700 font-bold text-lg">Sent</div>
                    <div className="text-amber-400 text-sm font-medium mt-1">This month</div>
                  </div>
                </div>
              </div>

              <Card className="border-none shadow-lg shadow-blue-900/5 rounded-3xl overflow-hidden">
                <CardHeader className="bg-white border-b border-slate-100 pb-4">
                  <CardTitle className="text-2xl font-black text-slate-800">Next 30 Days</CardTitle>
                  <CardDescription className="text-slate-500 font-medium">Manage and generate birthday assets for upcoming celebrations.</CardDescription>
                </CardHeader>
                <CardContent className="p-0">
                  <Table>
                    <TableHeader className="bg-slate-50/50">
                      <TableRow className="hover:bg-transparent border-slate-100">
                        <TableHead className="font-bold text-slate-500 uppercase tracking-wider text-xs py-4 pl-6">Employee</TableHead>
                        <TableHead className="font-bold text-slate-500 uppercase tracking-wider text-xs py-4">Department</TableHead>
                        <TableHead className="font-bold text-slate-500 uppercase tracking-wider text-xs py-4">Date</TableHead>
                        <TableHead className="font-bold text-slate-500 uppercase tracking-wider text-xs py-4">Status</TableHead>
                        <TableHead className="font-bold text-slate-500 uppercase tracking-wider text-xs py-4 text-right pr-6">Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {[...employees]
                        .filter(e => {
                          const nextBday = getNextBirthday(e.birthdate);
                          const today = new Date();
                          today.setHours(0, 0, 0, 0);
                          const diffTime = nextBday.getTime() - today.getTime();
                          const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                          return diffDays >= 0 && diffDays <= 30;
                        })
                        .sort((a, b) => getNextBirthday(a.birthdate).getTime() - getNextBirthday(b.birthdate).getTime())
                        .map((employee) => {
                        const nextBday = getNextBirthday(employee.birthdate);
                        const isTom = isBirthdayTomorrow(employee.birthdate);
                        
                        return (
                          <TableRow key={employee.id} className="border-slate-100 hover:bg-blue-50/50 transition-colors">
                            <TableCell className="pl-6 py-4">
                              <div className="flex items-center gap-4">
                                <div className="relative">
                                  <img src={(employee.uploadedPhotos && employee.uploadedPhotos.length > 0) ? employee.uploadedPhotos[0] : employee.avatar} alt={employee.name} className="w-12 h-12 rounded-full object-cover border-2 border-white shadow-sm" />
                                  {isTom && <div className="absolute -top-1 -right-1 w-4 h-4 bg-pink-500 rounded-full border-2 border-white" />}
                                </div>
                                <div>
                                  <div className="font-bold text-slate-800">{employee.name}</div>
                                  <div className="text-xs text-slate-500 font-medium">{employee.department}</div>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell className="py-4 font-medium text-slate-600">{employee.department}</TableCell>
                            <TableCell className="py-4">
                              <div className="flex flex-col">
                                <span className="font-bold text-slate-700">{format(nextBday, 'MMM do')}</span>
                                {isTom && <span className="text-xs font-bold text-pink-500">Tomorrow</span>}
                              </div>
                            </TableCell>
                            <TableCell className="py-4">
                              {employee.generatedAssets ? (
                                <span className="px-3 py-1 text-xs font-bold bg-green-100 text-green-700 rounded-full">Ready</span>
                              ) : (
                                <span className="px-3 py-1 text-xs font-bold bg-slate-100 text-slate-600 rounded-full">Pending</span>
                              )}
                            </TableCell>
                            <TableCell className="text-right pr-6 py-4">
                              <Button size="sm" onClick={() => openEmployeeDialog(employee)} className={`rounded-full font-bold shadow-sm ${employee.generatedAssets ? 'bg-green-50 text-green-600 border border-green-200 hover:bg-green-100 hover:border-green-300' : 'bg-white text-blue-600 border border-blue-200 hover:bg-blue-50 hover:border-blue-300'}`}>
                                {employee.generatedAssets ? 'View Assets' : 'Prepare'}
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </div>
          )}
          
          {currentView === 'directory' && (
            <Card className="border-none shadow-lg shadow-blue-900/5 rounded-3xl overflow-hidden max-w-6xl mx-auto">
              <CardHeader className="bg-white border-b border-slate-100 pb-4 flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-2xl font-black text-slate-800">All Employees</CardTitle>
                  <CardDescription className="text-slate-500 font-medium">Manage your organization's employee records.</CardDescription>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Label htmlFor="department-filter" className="text-sm font-bold text-slate-500 whitespace-nowrap">Filter by:</Label>
                    <select 
                      id="department-filter"
                      value={selectedDepartment}
                      onChange={(e) => setSelectedDepartment(e.target.value)}
                      className="h-10 px-4 py-1 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      {departments.map(dept => (
                        <option key={dept} value={dept}>{dept}</option>
                      ))}
                    </select>
                  </div>
                  <Button onClick={handleOpenAddEmployee} className="rounded-full font-bold bg-blue-600 hover:bg-blue-700 text-white shadow-md shadow-blue-500/20 px-6">
                    <Plus className="w-4 h-4 mr-2" />
                    Add Employee
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader className="bg-slate-50/50">
                    <TableRow className="hover:bg-transparent border-slate-100">
                      <TableHead className="font-bold text-slate-500 uppercase tracking-wider text-xs py-4 pl-6">Employee</TableHead>
                      <TableHead className="font-bold text-slate-500 uppercase tracking-wider text-xs py-4">Department</TableHead>
                      <TableHead className="font-bold text-slate-500 uppercase tracking-wider text-xs py-4">Birthdate</TableHead>
                      <TableHead className="font-bold text-slate-500 uppercase tracking-wider text-xs py-4 text-right pr-6">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredDirectoryEmployees.map((employee) => {
                      const bdate = new Date(employee.birthdate);
                      return (
                        <TableRow key={employee.id} className="border-slate-100 hover:bg-blue-50/50 transition-colors">
                          <TableCell className="pl-6 py-4">
                            <div className="flex items-center gap-4">
                              <img src={(employee.uploadedPhotos && employee.uploadedPhotos.length > 0) ? employee.uploadedPhotos[0] : employee.avatar} alt={employee.name} className="w-12 h-12 rounded-full object-cover border-2 border-white shadow-sm" />
                              <div>
                                <div className="font-bold text-slate-800">{employee.name}</div>
                                <div className="text-xs text-slate-500 font-medium">{employee.email || 'No email'}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell className="py-4 font-medium text-slate-600">
                            <span className="px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-bold">{employee.department}</span>
                          </TableCell>
                          <TableCell className="py-4">
                            <div className="flex items-center gap-2 text-slate-600 font-medium">
                              <Calendar className="w-4 h-4 text-blue-400" />
                              <span>{format(bdate, 'MMM do, yyyy')}</span>
                            </div>
                          </TableCell>
                          <TableCell className="text-right pr-6 py-4">
                            <div className="flex items-center justify-end gap-2">
                              <Button variant="ghost" size="icon" onClick={() => handleOpenEditEmployee(employee)} className="text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-full">
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button variant="ghost" size="icon" onClick={() => handleDeleteEmployee(employee.id)} className="text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-full">
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}

          {currentView === 'settings' && (
            <Card>
              <CardHeader>
                <CardTitle>Settings</CardTitle>
                <CardDescription>Manage application preferences and configurations.</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6 max-w-2xl">
                  <div>
                    <h3 className="text-lg font-medium mb-4">General Settings</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 border border-slate-200 rounded-lg">
                        <div>
                          <Label className="text-base font-medium">Email Notifications</Label>
                          <p className="text-sm text-slate-500">Receive email reminders for upcoming birthdays.</p>
                        </div>
                        <Checkbox defaultChecked />
                      </div>
                      <div className="flex items-center justify-between p-4 border border-slate-200 rounded-lg">
                        <div>
                          <Label className="text-base font-medium">WhatsApp Integration</Label>
                          <p className="text-sm text-slate-500">Enable WhatsApp messaging for HR reminders.</p>
                        </div>
                        <Checkbox defaultChecked />
                      </div>
                      <div className="flex items-center justify-between p-4 border border-slate-200 rounded-lg">
                        <div>
                          <Label className="text-base font-medium">Auto-Generate Assets</Label>
                          <p className="text-sm text-slate-500">Automatically generate video and flyer 3 days before birthday.</p>
                        </div>
                        <Checkbox />
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-4 border-t border-slate-200">
                    <h3 className="text-lg font-medium mb-4">Company Profile</h3>
                    <div className="space-y-4">
                      <div className="grid gap-2">
                        <Label htmlFor="company-name">Company Name</Label>
                        <Input id="company-name" defaultValue="NCPL Consulting" />
                      </div>
                      <div className="grid gap-2">
                        <Label htmlFor="default-music">Default Video Music</Label>
                        <select 
                          id="default-music"
                          className="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          {MUSIC_OPTIONS.map(opt => (
                            <option key={opt.id} value={opt.id}>{opt.name}</option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-4 flex justify-end">
                    <Button onClick={() => {
                      toast.success('Settings saved successfully');
                    }}>
                      Save Changes
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </main>

      {/* Asset Generation Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-4xl md:max-w-5xl w-[95vw] max-h-[90vh] overflow-y-auto overflow-x-hidden">
          <DialogHeader>
            <DialogTitle>Prepare Birthday Assets for {selectedEmployee?.name}</DialogTitle>
            <DialogDescription>
              Upload photos and generate the personalized video, flyer, and reminder.
            </DialogDescription>
          </DialogHeader>

          {showSuccessConfirmation ? (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200, damping: 15 }}
                className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4"
              >
                <CheckCircle2 className="w-10 h-10 text-green-600" />
              </motion.div>
              <motion.h2 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-2xl font-bold text-slate-900"
              >
                Assets Approved!
              </motion.h2>
              <motion.p 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="text-slate-600 max-w-md text-lg"
              >
                {successMessage}
              </motion.p>
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
              >
                <Button className="mt-6" onClick={() => {
                  setShowSuccessConfirmation(false);
                  setIsDialogOpen(false);
                }}>
                  Done
                </Button>
              </motion.div>
            </div>
          ) : !generatedAssets ? (
            <div className="space-y-6 py-4">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">1. Upload Photos & Logos</h3>
                <p className="text-sm text-slate-500">Please upload 3-4 high-quality photos of the employee and the NCPL logo for the video.</p>
                
                <div className="grid grid-cols-5 gap-4">
                  {uploadedPhotos.map((photo, i) => (
                    <div key={i} className="relative aspect-square rounded-md overflow-hidden border border-slate-200 group">
                      <img src={photo} alt={`Upload ${i+1}`} className="w-full h-full object-cover" />
                      <button
                        onClick={() => removePhoto(i)}
                        className="absolute top-1 right-1 bg-black/50 hover:bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Remove photo"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                  {uploadedPhotos.length < 4 && (
                    <Label className="relative aspect-square rounded-md border-2 border-dashed border-slate-300 hover:border-blue-500 hover:bg-blue-50 transition-colors flex flex-col items-center justify-center cursor-pointer text-slate-500">
                      <Upload className="w-6 h-6 mb-2" />
                      <span className="text-xs font-medium text-center">Upload<br/>Photo</span>
                      <Input type="file" accept="image/*" multiple className="hidden" onChange={handlePhotoUpload} />
                    </Label>
                  )}
                  {uploadedLogo ? (
                    <div className="relative aspect-square rounded-md overflow-hidden border border-indigo-200 group">
                      <img src={uploadedLogo} alt="NCPL Logo" className="w-full h-full object-contain p-2" />
                      <button
                        onClick={removeLogo}
                        className="absolute top-1 right-1 bg-black/50 hover:bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Remove logo"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ) : (
                    <Label className="relative aspect-square rounded-md border-2 border-dashed border-indigo-300 hover:border-indigo-500 hover:bg-indigo-50 transition-colors flex flex-col items-center justify-center cursor-pointer text-indigo-500">
                      <Upload className="w-6 h-6 mb-2" />
                      <span className="text-xs font-medium text-center">Upload<br/>Logo</span>
                      <Input type="file" accept="image/*" className="hidden" onChange={handleLogoUpload} />
                    </Label>
                  )}
                  {externalVideoUrl ? (
                    <div className="relative aspect-square rounded-md overflow-hidden border border-green-200 group col-span-2">
                       <video src={externalVideoUrl} className="w-full h-full object-cover" controls />
                       <button
                         onClick={removeExternalVideo}
                         className="absolute top-1 right-1 bg-black/50 hover:bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                         title="Remove video"
                       >
                         <X className="w-3 h-3" />
                       </button>
                    </div>
                  ) : (
                    <Label className="relative aspect-square rounded-md border-2 border-dashed border-green-300 hover:border-green-500 hover:bg-green-50 transition-colors flex flex-col items-center justify-center cursor-pointer text-green-500 col-span-2">
                      <Video className="w-6 h-6 mb-2" />
                      <span className="text-xs font-medium text-center">Upload Pre-made<br/>Video (Optional)</span>
                      <Input type="file" accept="video/mp4,video/webm" className="hidden" onChange={handleExternalVideoUpload} />
                    </Label>
                  )}
                </div>
                <p className="text-xs text-slate-500">{uploadedPhotos.length}/4 photos uploaded. (Optional) Provide an outside pre-made video directly.</p>
              </div>

              <div className="space-y-4">
                <h3 className="text-lg font-medium">2. Select Background Music</h3>
                <p className="text-sm text-slate-500">Choose a track to set the mood for the birthday video.</p>
                <div className="grid grid-cols-2 gap-3">
                  {MUSIC_OPTIONS.map((music) => (
                    <div 
                      key={music.id}
                      onClick={() => setSelectedMusic(music.id)}
                      className={`p-3 rounded-md border cursor-pointer flex items-center gap-3 transition-colors ${selectedMusic === music.id ? 'border-blue-500 bg-blue-50 text-blue-700' : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50 text-slate-700'}`}
                    >
                      <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${selectedMusic === music.id ? 'border-blue-500' : 'border-slate-300'}`}>
                        {selectedMusic === music.id && <div className="w-2 h-2 rounded-full bg-blue-500" />}
                      </div>
                      <span className="font-medium text-sm">{music.name}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">3. AI Configuration & Generation</h3>
                  <div className="flex items-center gap-2 bg-blue-50 px-3 py-1.5 rounded-full border border-blue-100">
                    <Label htmlFor="thinking-mode" className="text-xs font-bold text-blue-700 cursor-pointer">Deep Thinking Mode</Label>
                    <Checkbox 
                      id="thinking-mode" 
                      checked={thinkingMode} 
                      onCheckedChange={(checked) => setThinkingMode(!!checked)} 
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label className="text-sm font-bold text-slate-700">Video Aspect Ratio</Label>
                    <div className="flex gap-2">
                      <Button 
                        variant={videoAspectRatio === "9:16" ? "default" : "outline"} 
                        size="sm" 
                        onClick={() => setVideoAspectRatio("9:16")}
                        className="flex-1 rounded-xl"
                      >
                        Vertical (9:16)
                      </Button>
                      <Button 
                        variant={videoAspectRatio === "16:9" ? "default" : "outline"} 
                        size="sm" 
                        onClick={() => setVideoAspectRatio("16:9")}
                        className="flex-1 rounded-xl"
                      >
                        Wide (16:9)
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Label className="text-sm font-bold text-slate-700">Background Music</Label>
                    <div className="flex gap-2">
                       <Button 
                        variant={musicDuration === "short" ? "default" : "outline"} 
                        size="sm" 
                        onClick={() => setMusicDuration("short")}
                        className="flex-1 rounded-xl"
                      >
                        Short Clip (30s)
                      </Button>
                      <Button 
                        variant={musicDuration === "full" ? "default" : "outline"} 
                        size="sm" 
                        onClick={() => setMusicDuration("full")}
                        className="flex-1 rounded-xl"
                      >
                        Full Track
                      </Button>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label className="text-sm font-bold text-slate-700">Flyer Aspect Ratio</Label>
                    <select 
                      value={imageAspectRatio}
                      onChange={(e) => setImageAspectRatio(e.target.value as any)}
                      className="w-full h-10 px-4 py-1 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="1:1">Square (1:1)</option>
                      <option value="9:16">Vertical (9:16)</option>
                      <option value="16:9">Widescreen (16:9)</option>
                      <option value="4:3">Standard (4:3)</option>
                      <option value="3:4">Portrait (3:4)</option>
                      <option value="2:3">Editorial (2:3)</option>
                      <option value="3:2">Classic (3:2)</option>
                      <option value="21:9">Ultra-Wide (21:9)</option>
                    </select>
                  </div>

                  <div className="space-y-3">
                    <Label className="text-sm font-bold text-slate-700">Image Quality / Size</Label>
                    <div className="flex gap-2">
                      <Button 
                        variant={imageSize === "1K" ? "default" : "outline"} 
                        size="sm" 
                        onClick={() => setImageSize("1K")}
                        className="flex-1 rounded-xl"
                      >
                        1K
                      </Button>
                      <Button 
                        variant={imageSize === "2K" ? "default" : "outline"} 
                        size="sm" 
                        onClick={() => setImageSize("2K")}
                        className="flex-1 rounded-xl"
                      >
                        2K
                      </Button>
                      <Button 
                        variant={imageSize === "4K" ? "default" : "outline"} 
                        size="sm" 
                        onClick={() => setImageSize("4K")}
                        className="flex-1 rounded-xl"
                      >
                        4K
                      </Button>
                    </div>
                  </div>
                </div>

                <Button 
                  onClick={handleGenerate} 
                  disabled={isGenerating || uploadedPhotos.length < 1}
                  className="w-full h-12 text-lg font-black bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white shadow-lg shadow-blue-500/30 rounded-2xl"
                >
                  {isGenerating ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-3 animate-spin" />
                      Designing Masterpieces...
                    </>
                  ) : (
                    <>
                      <Video className="w-5 h-5 mr-3" />
                      Generate All Birthday Assets
                    </>
                  )}
                </Button>
              </div>
            </div>
          ) : (
            <div className="space-y-6 py-4">
              <div className="flex items-center gap-2 text-green-600 bg-green-50 p-3 rounded-md">
                <CheckCircle2 className="w-5 h-5" />
                <span className="font-medium">All assets generated successfully!</span>
              </div>

              <Tabs defaultValue="video" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="video"><Video className="w-4 h-4 mr-2" /> Video <span className="hidden sm:inline">Output</span></TabsTrigger>
                  <TabsTrigger value="flyer"><ImageIcon className="w-4 h-4 mr-2" /> Flyer</TabsTrigger>
                  <TabsTrigger value="music"><Volume2 className="w-4 h-4 mr-2" /> Music</TabsTrigger>
                  <TabsTrigger value="reminder"><MessageSquare className="w-4 h-4 mr-2" /> Reminder</TabsTrigger>
                </TabsList>
                
                <TabsContent value="video" className="mt-4">
                  <Card className="overflow-hidden border-none shadow-inner bg-slate-50">
                    <CardHeader className="bg-white border-b border-slate-100 pb-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-lg font-black text-slate-800">AI Video Generation (Or Upload)</CardTitle>
                          <CardDescription className="text-slate-500 font-medium font-sans">Cinematic animation or your pre-made file</CardDescription>
                        </div>
                        <div className="flex gap-2 items-center">
                          <Label className="cursor-pointer inline-flex items-center justify-center rounded-full text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 border border-slate-200 bg-white shadow-sm hover:bg-slate-100 h-9 px-6 text-slate-700">
                            <Upload className="w-4 h-4 mr-2" />
                            Upload Video
                            <Input type="file" accept="video/mp4,video/webm" className="hidden" onChange={handleExternalVideoUpload} />
                          </Label>
                          <Button 
                            onClick={handleGenerateVideoAI} 
                            disabled={isGeneratingVideoAI} 
                            size="sm"
                            className="rounded-full bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-500/20 px-6"
                          >
                            {isGeneratingVideoAI ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Video className="w-4 h-4 mr-2" />}
                            Animate with AI
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6">
                      {/* Asset Preparation Section */}
                      <div className="mb-10 space-y-8">
                        <div className="p-8 bg-white rounded-[2.5rem] border border-slate-100 shadow-[0_8px_30px_rgb(0,0,0,0.04)] ring-1 ring-slate-200">
                          <div className="flex items-center justify-between mb-8">
                            <h4 className="font-black text-slate-800 flex items-center gap-3 uppercase tracking-[0.2em] text-[10px]">
                              <div className="p-2 bg-blue-50 rounded-lg">
                                <UserCheck className="w-5 h-5 text-blue-600" />
                              </div>
                              Role Mapping & Storyboard
                            </h4>
                            <div className="flex gap-2">
                              {['9:16', '16:9'].map((ratio) => (
                                <Button
                                  key={ratio}
                                  variant={videoAspectRatio === ratio ? 'default' : 'outline'}
                                  onClick={() => setVideoAspectRatio(ratio as any)}
                                  size="sm"
                                  className="h-8 rounded-full text-[10px] font-black uppercase tracking-wider"
                                >
                                  {ratio}
                                </Button>
                              ))}
                            </div>
                          </div>

                          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                            <div className="space-y-6">
                              <div className="flex items-center justify-between">
                                <Label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Main Subject</Label>
                                <span className="bg-blue-600 text-white px-2 py-0.5 rounded-full text-[8px] font-black uppercase">Primary Slot</span>
                              </div>
                              <div className="flex items-center gap-6 p-4 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                                <div className="group relative w-32 h-32 rounded-3xl border-4 border-white overflow-hidden shadow-xl bg-slate-200 transition-all hover:scale-[1.02]">
                                  {uploadedPhotos[mainPersonPhotoIndex] || selectedEmployee?.avatar ? (
                                    <img 
                                      src={uploadedPhotos[mainPersonPhotoIndex] || selectedEmployee?.avatar} 
                                      className="w-full h-full object-cover" 
                                      alt="Main Person"
                                    />
                                  ) : (
                                    <div className="flex items-center justify-center h-full text-slate-300"><UserIcon className="w-10 h-10" /></div>
                                  )}
                                  <div className="absolute inset-0 bg-blue-600/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-[2px]">
                                    <Play className="w-8 h-8 text-white fill-white" />
                                  </div>
                                </div>
                                <div className="flex-1 space-y-2">
                                  <p className="text-xl font-black text-slate-800 leading-tight">{selectedEmployee?.name}</p>
                                  <div className="text-[12px] text-slate-500 font-medium flex items-center gap-1.5">
                                    <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                                    AI Face-Mapping Active
                                  </div>
                                  <div className="flex gap-2 mt-4">
                                    <Button variant="outline" size="sm" className="h-7 text-[9px] font-black uppercase rounded-lg border-slate-200" onClick={() => {/* Future implementation: Individual edit */}}>
                                      Edit Portrait
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="space-y-6">
                              <div className="flex items-center justify-between">
                                <Label className="text-[10px] font-black uppercase text-slate-400 tracking-wider">Team Ensemble ({uploadedPhotos.length})</Label>
                                <Label className="text-[10px] font-black uppercase text-blue-600 cursor-pointer hover:underline">Select ALL</Label>
                              </div>
                              <div className="flex flex-wrap gap-3">
                                {uploadedPhotos.map((photo, i) => (
                                  <motion.div 
                                    key={i}
                                    whileHover={{ scale: 1.1 }}
                                    onClick={() => setMainPersonPhotoIndex(i)}
                                    className={`relative w-14 h-14 rounded-2xl overflow-hidden cursor-pointer transition-all border-4 shadow-sm ${i === mainPersonPhotoIndex ? 'border-blue-500 ring-4 ring-blue-100 scale-110 z-10' : 'border-white hover:border-slate-200'}`}
                                  >
                                    <img src={photo} alt={`Colleague ${i+1}`} className="w-full h-full object-cover" />
                                    {i === mainPersonPhotoIndex ? (
                                      <div className="absolute inset-0 bg-blue-500/20 flex items-center justify-center">
                                        <CheckCircle2 className="w-4 h-4 text-white" />
                                      </div>
                                    ) : (
                                      <div className="absolute top-1 right-1 w-3 h-3 bg-white/80 rounded-full flex items-center justify-center">
                                        <span className="text-[6px] font-black text-slate-800">{i + 1}</span>
                                      </div>
                                    )}
                                  </motion.div>
                                ))}
                                {uploadedPhotos.length < 8 && (
                                  <Label className="relative w-14 h-14 rounded-2xl border-4 border-dashed border-slate-200 hover:border-blue-500 hover:bg-blue-50 transition-all flex flex-col items-center justify-center cursor-pointer text-slate-400 group">
                                    <Plus className="w-5 h-5 group-hover:scale-110 transition-transform" />
                                    <Input type="file" accept="image/*" multiple className="hidden" onChange={handlePhotoUpload} />
                                  </Label>
                                )}
                              </div>
                              <p className="text-[10px] text-slate-400 italic">Photos mapped to Slot 1-8 will appear in the team celebration scenes.</p>
                            </div>
                          </div>

                          {/* Storyboard Visualization */}
                          <div className="mt-12 pt-8 border-t border-slate-100 grid grid-cols-2 md:grid-cols-4 gap-4">
                            {[
                              { label: 'Introduction', text: 'Team Scene', icon: Users },
                              { label: 'Featured', text: 'Birthday Hero', icon: UserIcon },
                              { label: 'The Moment', text: 'Cake Close-up', icon: Plus }, // Using plus as cake holder
                              { label: 'Finale', text: 'Team Applause', icon: CheckCircle2 },
                            ].map((scene, idx) => (
                              <div key={idx} className="relative group p-4 bg-slate-50/50 rounded-2xl border border-transparent hover:border-blue-100 transition-all">
                                <div className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-2">Scene 0{idx+1}</div>
                                <div className="flex items-center gap-2">
                                  <scene.icon className="w-3 h-3 text-blue-400" />
                                  <span className="text-[11px] font-bold text-slate-700">{scene.label}</span>
                                </div>
                                <p className="text-[9px] text-slate-500 mt-1">{scene.text}</p>
                                {idx < 3 && <div className="absolute -right-3 top-1/2 -translate-y-1/2 hidden md:block text-slate-200">→</div>}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
                        <div 
                          className={`relative mx-auto rounded-[2rem] overflow-hidden shadow-2xl border-4 border-white ring-1 ring-slate-200 ${videoAspectRatio === '9:16' ? 'w-[280px] aspect-[9/16]' : 'w-full aspect-[16/9]'}`}
                        >
                          {(generatedVideoUrl || externalVideoUrl) ? (
                            <video 
                              src={generatedVideoUrl || externalVideoUrl || ''} 
                              controls 
                              className="w-full h-full object-cover"
                              autoPlay
                            />
                          ) : (
                            <div className="absolute inset-0 bg-slate-200 flex flex-col items-center justify-center text-slate-400 p-8 text-center italic">
                              <Video className="w-12 h-12 mb-4 opacity-20" />
                              <p className="font-medium text-slate-500">Click "Animate with AI" to create a cinematic celebration, or upload a pre-made video.</p>
                            </div>
                          )}
                        </div>

                        <div className="space-y-6">
                          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                            <h4 className="font-bold text-slate-800 mb-2 flex items-center gap-2">
                              <MessageSquare className="w-4 h-4 text-blue-500" />
                              Creative Storyboard
                            </h4>
                            <p className="text-slate-600 text-sm italic leading-relaxed">
                              "{generatedAssets?.videoDescription || 'Initial instructions: Cinematic office celebration with cake and friends.'}"
                            </p>
                          </div>
                          
                          {generatedMusicUrl && (
                            <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
                              <h4 className="font-bold text-slate-800 mb-2 flex items-center gap-2">
                                <Volume2 className="w-4 h-4 text-purple-500" />
                                AI Generated Soundtrack
                              </h4>
                              <audio src={generatedMusicUrl} controls className="w-full h-10 mt-2 rounded-full accent-blue-500" />
                            </div>
                          )}

                          <div className="flex flex-col gap-3 pt-4">
                            <Button variant="outline" className="w-full rounded-2xl justify-start h-12 border-slate-200 hover:bg-slate-50" onClick={handleDownloadVideo}>
                              <Upload className="w-4 h-4 mr-3 rotate-180" /> View Local Canvas Preview
                            </Button>
                            {generatedVideoUrl && (
                               <Button variant="default" className="w-full rounded-2xl justify-start h-12 bg-green-600 hover:bg-green-700 shadow-md shadow-green-500/20" asChild>
                                 <a href={generatedVideoUrl} target="_blank" rel="noopener noreferrer">
                                   <Video className="w-4 h-4 mr-3" /> Download High Quality AI Video
                                 </a>
                               </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                    <CardFooter className="bg-slate-50 p-4 flex justify-end">
                      <Button variant="outline" onClick={handleDownloadVideo} disabled={isGeneratingVideo}>
                        {isGeneratingVideo ? (
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        ) : (
                          <Video className="w-4 h-4 mr-2" />
                        )}
                        {isGeneratingVideo ? 'Generating...' : 'Download Video'}
                      </Button>
                    </CardFooter>
                  </Card>
                </TabsContent>
                
                <TabsContent value="flyer" className="mt-4">
                  <Card className="overflow-hidden border-none shadow-inner bg-slate-50">
                    <CardHeader className="bg-white border-b border-slate-100 pb-4">
                       <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-lg font-black text-slate-800">AI Professional Flyer</CardTitle>
                          <CardDescription className="text-slate-500 font-medium">Visuals by Gemini 3.1 & 3.0 Pro</CardDescription>
                        </div>
                        <div className="flex items-center gap-3">
                          <Input 
                            placeholder="AI Edit Prompt (e.g. 'Add more blue balloons')..." 
                            value={imagePrompt}
                            onChange={(e) => setImagePrompt(e.target.value)}
                            className="w-72 rounded-xl border-blue-100 bg-white shadow-sm"
                          />
                          <Button 
                            onClick={handleEditImageAI} 
                            disabled={isGeneratingImage || !generatedImageUrl} 
                            size="sm"
                            className="rounded-full bg-purple-600 hover:bg-purple-700 shadow-lg shadow-purple-500/20 px-6"
                          >
                            {isGeneratingImage ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Edit className="w-4 h-4 mr-2" />}
                            AI Re-Style
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-0 overflow-hidden">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-0 min-h-[500px]">
                        <div className="bg-white p-12 flex flex-col justify-center items-center text-center border-r border-slate-100">
                          {/* Flyer Preview Component */}
                          <div 
                            ref={flyerRef}
                            className={`relative shadow-[0_20px_50px_rgba(0,0,0,0.1)] overflow-hidden rounded-[2rem] border border-slate-100 bg-white transition-all duration-500 ${imageAspectRatio === '1:1' ? 'aspect-square w-full max-w-sm' : imageAspectRatio === '9:16' ? 'aspect-[9/16] w-64' : 'aspect-[3/4] w-72'}`}
                          >
                            {generatedImageUrl ? (
                              <img src={generatedImageUrl} alt="AI Background" className="absolute inset-0 w-full h-full object-cover" />
                            ) : (
                              <div className="absolute inset-0 bg-blue-50 flex items-center justify-center">
                                <ImageIcon className="w-12 h-12 text-blue-200" />
                              </div>
                            )}
                            <div className={`absolute inset-0 bg-gradient-to-b ${FLYER_STYLES[flyerStyleIndex].bg}`} />
                            <div className={`relative h-full flex flex-col p-8 z-10 transition-all duration-500 ${FLYER_ALIGNS[flyerAlignIndex].container} ${FLYER_ALIGNS[flyerAlignIndex].justify}`}>
                              {uploadedLogo && (
                                <div className="bg-white/90 backdrop-blur-md p-3 rounded-2xl shadow-sm mb-6 max-w-fit">
                                  <img src={uploadedLogo} alt="NCPL" className="w-12 h-12 object-contain" />
                                </div>
                              )}
                              <h2 className={`text-4xl font-black mb-6 tracking-tight leading-none drop-shadow-sm ${FLYER_STYLES[flyerStyleIndex].text}`}>{generatedAssets?.flyerHeadline || 'Happy Birthday!'}</h2>
                              <div 
                                className={`w-36 h-36 rounded-full border-4 ${FLYER_STYLES[flyerStyleIndex].border} shadow-2xl mb-8 overflow-hidden transform hover:scale-105 transition-all duration-300 cursor-pointer relative group`}
                                onClick={() => {
                                  if (uploadedPhotos.length > 0) {
                                    setFlyerPhotoIndex((prev) => (prev + 1) % (uploadedPhotos.length + 1));
                                  }
                                }}
                                title="Click to swap image"
                              >
                                <img 
                                  crossOrigin="anonymous"
                                  src={flyerPhotoIndex > 0 && uploadedPhotos.length > 0 ? uploadedPhotos[flyerPhotoIndex - 1] : (selectedEmployee?.avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(selectedEmployee?.name || 'Employee')}&background=random`)} 
                                  alt={selectedEmployee?.name} 
                                  className="w-full h-full object-cover"
                                  onError={(e) => {
                                    e.currentTarget.src = `https://ui-avatars.com/api/?name=${encodeURIComponent(selectedEmployee?.name || 'Employee')}&background=0D8ABC&color=fff&size=150`;
                                  }}
                                />
                                {uploadedPhotos.length > 0 && (
                                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                    <span className="text-white text-xs font-bold px-3 py-1.5 bg-black/60 rounded-full shadow-lg backdrop-blur-md">Swap Photo</span>
                                  </div>
                                )}
                              </div>
                              <div className={`space-y-4 ${FLYER_ALIGNS[flyerAlignIndex].textWrap}`}>
                                <h3 className={`text-2xl font-black tracking-tight ${FLYER_STYLES[flyerStyleIndex].text}`}>{selectedEmployee?.name}</h3>
                                <p className={`font-bold leading-relaxed italic text-sm ${FLYER_STYLES[flyerStyleIndex].pText}`}>"{generatedAssets?.flyerMessage || 'Wishing you an amazing year ahead!'}"</p>
                              </div>
                              <div className={`mt-8 pt-6 border-t opacity-40 ${FLYER_STYLES[flyerStyleIndex].border} w-full`}>
                                <p className={`font-black text-xs uppercase tracking-[0.2em] ${FLYER_STYLES[flyerStyleIndex].text}`}>{selectedEmployee?.department || 'TEAM MEMBER'}</p>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="bg-slate-50/50 p-10 flex flex-col gap-6">
                            <div className="space-y-4">
                              <div className="flex flex-col gap-2">
                                <Label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Color Theme</Label>
                                <div className="flex gap-2 w-full">
                                   {FLYER_STYLES.map((style, idx) => (
                                       <Button 
                                          key={idx}
                                          variant={idx === flyerStyleIndex ? "default" : "outline"} 
                                          size="sm"
                                          className={`flex-1 text-[10px] uppercase font-bold transition-all ${idx === flyerStyleIndex ? 'bg-purple-600 hover:bg-purple-700 text-white border-transparent' : 'text-slate-600 hover:bg-slate-100'}`}
                                          onClick={() => setFlyerStyleIndex(idx)}
                                       >
                                          {style.label}
                                       </Button>
                                   ))}
                                </div>
                              </div>
                              <div className="flex flex-col gap-2">
                                <Label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Layout Style</Label>
                                <div className="flex gap-2 w-full">
                                   {FLYER_ALIGNS.map((align, idx) => (
                                       <Button 
                                          key={idx}
                                          variant={idx === flyerAlignIndex ? "default" : "outline"} 
                                          size="sm"
                                          className={`flex-1 text-[10px] uppercase font-bold transition-all ${idx === flyerAlignIndex ? 'bg-blue-600 hover:bg-blue-700 text-white border-transparent' : 'text-slate-600 hover:bg-blue-50'}`}
                                          onClick={() => setFlyerAlignIndex(idx)}
                                       >
                                          {align.label}
                                       </Button>
                                   ))}
                                </div>
                              </div>
                            </div>
                           <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
                            <h4 className="font-extrabold text-slate-800 mb-3 flex items-center gap-2">
                              <ImageIcon className="w-5 h-5 text-purple-500" />
                              Visual Blueprint
                            </h4>
                            <p className="text-slate-600 text-sm italic leading-relaxed font-medium">
                              "{generatedAssets?.flyerBackgroundImagePrompt || 'Festive office celebration background...'}"
                            </p>
                            <div className="mt-4 flex gap-2">
                              <span className="px-3 py-1 bg-slate-100 rounded-full text-[10px] font-black text-slate-500 uppercase tracking-widest">{imageAspectRatio} Ratio</span>
                              <span className="px-3 py-1 bg-slate-100 rounded-full text-[10px] font-black text-slate-500 uppercase tracking-widest">{imageSize} Quality</span>
                            </div>
                          </div>

                          <div className="flex flex-col gap-4 mt-auto">
                            <Button onClick={handleDownloadFlyer} className="w-full rounded-2xl h-14 text-lg font-black bg-slate-900 hover:bg-slate-800 text-white shadow-xl shadow-slate-200">
                              <ImageIcon className="w-5 h-5 mr-3" /> Save to PNG
                            </Button>
                            <Button variant="outline" onClick={handleShareFlyer} className="w-full rounded-2xl h-14 text-lg font-black border-2 border-blue-100 text-blue-600 hover:bg-blue-50">
                              <Mail className="w-5 h-5 mr-3" /> Distribute via Email
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="music" className="mt-4">
                  <Card className="overflow-hidden border-none shadow-inner bg-slate-50">
                    <CardHeader className="bg-white border-b border-slate-100 pb-4">
                       <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-lg font-black text-slate-800">AI Custom Music</CardTitle>
                          <CardDescription className="text-slate-500 font-medium">Generate personalized soundtracks</CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label className="text-sm font-bold text-slate-700">Musical Style & Vibe</Label>
                            <textarea 
                              className="w-full min-h-[100px] p-3 border border-slate-200 rounded-xl text-sm"
                              placeholder="e.g. Upbeat acoustic guitar with joyful melodies..."
                              value={musicPrompt}
                              onChange={(e) => setMusicPrompt(e.target.value)}
                            />
                          </div>
                          
                          <div className="space-y-2">
                            <Label className="text-sm font-bold text-slate-700">Duration</Label>
                            <div className="flex gap-2">
                              <Button 
                                variant={musicDuration === "short" ? "default" : "outline"} 
                                onClick={() => setMusicDuration("short")}
                                className="flex-1 rounded-xl"
                              >
                                Short Clip (30s)
                              </Button>
                              <Button 
                                variant={musicDuration === "full" ? "default" : "outline"} 
                                onClick={() => setMusicDuration("full")}
                                className="flex-1 rounded-xl"
                              >
                                Full Track
                              </Button>
                            </div>
                          </div>
                          
                          <Button 
                            onClick={handleGenerateCustomMusic} 
                            disabled={isGeneratingMusic || !musicPrompt} 
                            className="w-full h-12 bg-purple-600 hover:bg-purple-700 text-white rounded-xl"
                          >
                            {isGeneratingMusic ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <Volume2 className="w-5 h-5 mr-2" />}
                            {isGeneratingMusic ? "Composing..." : "Generate Custom Music"}
                          </Button>
                        </div>
                        
                        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex flex-col justify-center items-center h-full min-h-[250px]">
                          {generatedMusicUrl ? (
                            <div className="w-full flex flex-col items-center">
                              <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mb-6 shadow-inner">
                                <Volume2 className="w-10 h-10 text-blue-500" />
                              </div>
                              <audio src={generatedMusicUrl} controls className="w-full mb-6 accent-blue-500" />
                              <Button asChild className="w-full rounded-xl border-2 border-slate-200 hover:bg-slate-50" variant="outline">
                                <a href={generatedMusicUrl} download={`Birthday_Music_${selectedEmployee?.name}.wav`}>
                                  <Upload className="w-4 h-4 mr-2 rotate-180" /> Download Audio
                                </a>
                              </Button>
                            </div>
                          ) : (
                            <div className="text-center text-slate-400 max-w-xs">
                              <VolumeX className="w-12 h-12 mx-auto mb-4 opacity-20" />
                              <p className="font-medium text-slate-500">No custom music generated yet.</p>
                              <p className="text-sm mt-2 text-slate-400">Describe your desired style and click Generate to create a custom birthday soundtrack.</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="reminder" className="mt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg flex items-center gap-2">
                          <MessageSquare className="w-5 h-5 text-green-600" />
                          WhatsApp Reminder
                        </CardTitle>
                        <CardDescription>To be sent at 11 PM the night before</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="bg-green-50 border border-green-200 p-4 rounded-md relative min-h-[120px]">
                          <div className="absolute -left-2 top-4 w-4 h-4 bg-green-50 border-t border-l border-green-200 rotate-[-45deg]"></div>
                          <p className="text-slate-800 whitespace-pre-wrap font-medium text-sm">
                            {generatedAssets.whatsappReminder}
                          </p>
                        </div>
                      </CardContent>
                      <CardFooter className="px-6 pb-6 pt-0 flex justify-end gap-2">
                        <Button variant="outline" size="sm" onClick={() => {
                          const text = encodeURIComponent(generatedAssets.whatsappReminder);
                          window.open(`https://wa.me/8919895688?text=${text}`, '_blank');
                        }}>
                          <MessageSquare className="w-4 h-4 mr-2" /> Send via WhatsApp
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => {
                          navigator.clipboard.writeText(generatedAssets.whatsappReminder);
                          toast.success('WhatsApp reminder copied to clipboard');
                        }}>
                          <MessageSquare className="w-4 h-4 mr-2" /> Copy
                        </Button>
                      </CardFooter>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="text-lg flex items-center gap-2">
                          <Mail className="w-5 h-5 text-blue-600" />
                          Email Reminder
                        </CardTitle>
                        <CardDescription>Schedule when this email should be sent</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="mb-4 flex gap-3">
                          <div className="flex-1 space-y-1">
                            <Label htmlFor="email-date" className="text-xs text-slate-500">Date</Label>
                            <Input 
                              id="email-date" 
                              type="date" 
                              value={emailScheduleDate} 
                              onChange={(e) => setEmailScheduleDate(e.target.value)} 
                              className={`h-8 text-sm ${isScheduleInPast() ? 'border-red-500 focus-visible:ring-red-500' : ''}`} 
                            />
                          </div>
                          <div className="flex-1 space-y-1">
                            <Label htmlFor="email-time" className="text-xs text-slate-500">Time</Label>
                            <Input 
                              id="email-time" 
                              type="time" 
                              value={emailScheduleTime} 
                              onChange={(e) => setEmailScheduleTime(e.target.value)} 
                              className={`h-8 text-sm ${isScheduleInPast() ? 'border-red-500 focus-visible:ring-red-500' : ''}`} 
                            />
                          </div>
                        </div>
                        {isScheduleInPast() && (
                          <div className="mb-4 text-xs text-red-500 font-medium">
                            Scheduled email date and time cannot be in the past.
                          </div>
                        )}
                        <div className="border border-slate-200 rounded-md overflow-hidden min-h-[120px]">
                          <div className="bg-slate-50 border-b border-slate-200 px-4 py-2 text-sm flex items-center">
                            <span className="font-semibold text-slate-600 mr-2">Subject:</span>
                            <Input 
                              value={generatedAssets.emailReminderSubject}
                              onChange={(e) => setGeneratedAssets({...generatedAssets, emailReminderSubject: e.target.value})}
                              className="h-7 text-sm border-transparent bg-transparent hover:border-slate-300 focus-visible:ring-1 focus-visible:ring-blue-500 px-2 py-1 flex-1"
                            />
                          </div>
                          <div className="p-0 bg-white h-full">
                            <textarea 
                              className="w-full h-full min-h-[100px] p-4 text-slate-800 text-sm resize-none border-none focus:ring-0 focus-visible:ring-0"
                              value={generatedAssets.emailReminderBody}
                              onChange={(e) => setGeneratedAssets({...generatedAssets, emailReminderBody: e.target.value})}
                            />
                          </div>
                        </div>
                      </CardContent>
                      <CardFooter className="px-6 pb-6 pt-0 flex justify-end gap-2">
                        <Button variant="outline" size="sm" onClick={() => {
                          const subject = encodeURIComponent(generatedAssets.emailReminderSubject);
                          const body = encodeURIComponent(generatedAssets.emailReminderBody);
                          window.location.href = `mailto:sushma.kandregula@ncplconsulting.net?subject=${subject}&body=${body}`;
                        }}>
                          <Mail className="w-4 h-4 mr-2" /> Send via Email
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => {
                          navigator.clipboard.writeText(`Subject: ${generatedAssets.emailReminderSubject}\n\n${generatedAssets.emailReminderBody}`);
                          toast.success('Email reminder copied to clipboard');
                        }}>
                          <Mail className="w-4 h-4 mr-2" /> Copy
                        </Button>
                      </CardFooter>
                    </Card>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          )}
          
          {!showSuccessConfirmation && (
            <DialogFooter className="flex sm:justify-between items-center w-full mt-4">
              {generatedAssets ? (
                <div className="flex items-center gap-6 text-sm">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="send-whatsapp" checked={sendWhatsApp} onCheckedChange={(c) => setSendWhatsApp(!!c)} />
                    <label htmlFor="send-whatsapp" className="font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer flex flex-col">
                      <span>Send WhatsApp</span>
                      <span className="text-xs text-slate-500">8919895688</span>
                    </label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="send-email" checked={sendEmail} onCheckedChange={(c) => setSendEmail(!!c)} />
                    <label htmlFor="send-email" className="font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer flex flex-col">
                      <span>Send Email</span>
                      <span className="text-xs text-slate-500">sushma.kandregula@ncplconsulting.net</span>
                    </label>
                  </div>
                </div>
              ) : (
                <div />
              )}
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)}>Close</Button>
                {generatedAssets && !showSuccessConfirmation && (
                  <Button onClick={() => {
                    let message = 'Assets approved!';
                    
                    if (sendEmail) {
                      if (!emailScheduleDate || !emailScheduleTime) {
                        toast.error('Please select a date and time for the email reminder.');
                        return;
                      }
                      
                      try {
                        const [year, month, day] = emailScheduleDate.split('-').map(Number);
                        const [hours, minutes] = emailScheduleTime.split(':').map(Number);
                        const scheduledDate = new Date(year, month - 1, day, hours, minutes);
                        
                        if (scheduledDate < new Date()) {
                          toast.error('Scheduled email date and time cannot be in the past.');
                          return;
                        }
                        
                        message += ` Email scheduled for ${format(scheduledDate, 'MMM d, yyyy')} at ${emailScheduleTime}.`;
                      } catch (e) {
                        message += ' Email scheduled.';
                      }
                    }
                    
                    if (sendWhatsApp) {
                      message += ' WhatsApp reminder scheduled.';
                    }
                    
                    setSuccessMessage(message);
                    setShowSuccessConfirmation(true);
                  }}>
                    Approve & Schedule
                  </Button>
                )}
              </div>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>

      {/* Employee Form Dialog */}
      <Dialog open={isEmployeeFormOpen} onOpenChange={setIsEmployeeFormOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingEmployee ? 'Edit Employee' : 'Add Employee'}</DialogTitle>
            <DialogDescription>
              {editingEmployee ? 'Update the details for this employee.' : 'Enter the details for the new employee.'}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex flex-col items-center gap-4 mb-4">
              <div className="relative w-24 h-24 rounded-full overflow-hidden bg-slate-100 border border-slate-200 flex items-center justify-center">
                {employeeFormData.avatar ? (
                  <img src={employeeFormData.avatar} alt="Avatar preview" className="w-full h-full object-cover" />
                ) : (
                  <Users className="w-8 h-8 text-slate-400" />
                )}
                <Label className="absolute inset-0 bg-black/50 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity cursor-pointer">
                  <Upload className="w-6 h-6 text-white" />
                  <Input type="file" accept="image/*" className="hidden" onChange={handleAvatarUpload} />
                </Label>
              </div>
              <span className="text-xs text-slate-500">Upload Avatar (Optional)</span>
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input 
                id="name" 
                value={employeeFormData.name} 
                onChange={(e) => setEmployeeFormData({ ...employeeFormData, name: e.target.value })}
                placeholder="e.g. Jane Doe"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="department">Department</Label>
              <Input 
                id="department" 
                value={employeeFormData.department} 
                onChange={(e) => setEmployeeFormData({ ...employeeFormData, department: e.target.value })}
                placeholder="e.g. Engineering"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="seniority">Seniority / Role</Label>
              <Input 
                id="seniority" 
                value={employeeFormData.seniority} 
                onChange={(e) => setEmployeeFormData({ ...employeeFormData, seniority: e.target.value })}
                placeholder="e.g. Senior, Executive, Associate"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="birthdate">Birthdate</Label>
              <Input 
                id="birthdate" 
                type="date"
                value={employeeFormData.birthdate} 
                onChange={(e) => setEmployeeFormData({ ...employeeFormData, birthdate: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email (Optional)</Label>
              <Input 
                id="email" 
                type="email"
                value={employeeFormData.email} 
                onChange={(e) => setEmployeeFormData({ ...employeeFormData, email: e.target.value })}
                placeholder="e.g. jane@ncpl.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="whatsapp">WhatsApp Number (Optional)</Label>
              <Input 
                id="whatsapp" 
                type="tel"
                value={employeeFormData.whatsapp} 
                onChange={(e) => setEmployeeFormData({ ...employeeFormData, whatsapp: e.target.value })}
                placeholder="e.g. +1234567890"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEmployeeFormOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveEmployee}>Save Employee</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      <Toaster />
    </div>
  );
}

