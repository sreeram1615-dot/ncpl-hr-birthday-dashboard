import { GoogleGenAI, ThinkingLevel, Modality, Type } from "@google/genai";

export function getAI() {
  return new GoogleGenAI({ apiKey: process.env.API_KEY || process.env.GEMINI_API_KEY });
}

export async function generateBirthdayText(employeeName: string, department: string, seniority: string) {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: `Generate birthday celebration content for an employee named ${employeeName}. 
    They work in the ${department} department and their seniority is: ${seniority}.
    Include:
    1. A catchy flyer headline tailored to their department and seniority.
    2. A warm and professional flyer message (2-3 sentences) referencing their department's work and seniority level.
    3. A short and engaging WhatsApp reminder (1 sentence).
    4. A professional email subject line.
    5. A professional email body for the team.`,
    config: {
      thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          flyerHeadline: { type: Type.STRING },
          flyerMessage: { type: Type.STRING },
          whatsappReminder: { type: Type.STRING },
          emailReminderSubject: { type: Type.STRING },
          emailReminderBody: { type: Type.STRING },
        },
        required: ["flyerHeadline", "flyerMessage", "whatsappReminder", "emailReminderSubject", "emailReminderBody"]
      }
    }
  });

  return JSON.parse(response.text);
}

export async function generateBirthdayImage(
  prompt: string, 
  aspectRatio: "1:1" | "3:4" | "4:3" | "9:16" | "16:9" | "2:3" | "3:2" | "21:9" = "1:1", 
  size: "1K" | "2K" | "4K" = "1K",
  logoDataUrl?: string | null
) {
  const parts: any[] = [];

  if (logoDataUrl) {
    const mimeTypeMatch = logoDataUrl.match(/data:([a-zA-Z0-9]+\/[a-zA-Z0-9-.+]+).*,.*/);
    const mimeType = mimeTypeMatch ? mimeTypeMatch[1] : "image/png";
    const base64Data = logoDataUrl.replace(/^data:image\/\w+;base64,/, "");
    parts.push({
      inlineData: {
        data: base64Data,
        mimeType: mimeType
      }
    });
    prompt += " Please seamlessly incorporate the provided logo image into the design/background.";
  }

  parts.push({ text: prompt });

  const ai = getAI();
  const response = await ai.models.generateContent({
    model: size === "1K" ? "gemini-3.1-flash-image-preview" : "gemini-3-pro-image-preview",
    contents: { parts },
    config: {
      imageConfig: {
        aspectRatio: aspectRatio as any,
        imageSize: size as any
      }
    }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
  }
  throw new Error("No image generated");
}

export async function generateBirthdayVideo(prompt: string, aspectRatio: "16:9" | "9:16" = "9:16") {
  try {
    const ai = getAI();
    let operation = await ai.models.generateVideos({
      model: "veo-3.1-lite-generate-preview",
      prompt: prompt,
      config: {
        numberOfVideos: 1,
        aspectRatio: aspectRatio,
      }
    });

    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 5000));
      operation = await ai.operations.getVideosOperation({ operation: operation });
    }

    if (operation.response) {
      const videoResult: any = operation.response;
      return videoResult.videos?.[0]?.uri || videoResult.generatedVideos?.[0]?.video?.uri;
    }
  } catch (error: any) {
    console.error("Video Generation Error:", error);
    if (error.message?.includes("PERMISSION_DENIED") || error.status === 403) {
      throw new Error("Permission Denied: Your API key may not have access to Veo 3.1. Please ensure you have selected a key with correct permissions.");
    }
    throw error;
  }
}

export async function generateBirthdayMusic(prompt: string, duration: "short" | "full" = "short") {
  try {
    const ai = getAI();
    const response = await ai.models.generateContentStream({
      model: duration === "short" ? "lyria-3-clip-preview" : "lyria-3-pro-preview",
      contents: prompt,
      config: {
        responseModalities: [Modality.AUDIO]
      }
    });

    let audioBase64 = "";
    let mimeType = "audio/wav";

    for await (const chunk of response) {
      const parts = chunk.candidates?.[0]?.content?.parts;
      if (!parts) continue;
      for (const part of parts) {
        if (part.inlineData?.data) {
          if (!audioBase64 && part.inlineData.mimeType) {
            mimeType = part.inlineData.mimeType;
          }
          audioBase64 += part.inlineData.data;
        }
      }
    }

    const binary = atob(audioBase64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    const blob = new Blob([bytes], { type: mimeType });
    return URL.createObjectURL(blob);
  } catch (error: any) {
    console.error("Music Generation Error:", error);
    if (error.message?.includes("PERMISSION_DENIED") || error.status === 403) {
      throw new Error("Permission Denied: Your API key may not have access to Lyria. Please ensure you have selected a key with correct permissions.");
    }
    throw error;
  }
}

export async function generateBirthdayAssets(
  employeeName: string,
  department: string,
  seniority: string,
  selectedMusicName: string = "Joyful and professional",
  animationStyle: string = "fade"
) {
  // This is a wrapper to preserve the existing interface if needed, but we'll likely move to fine-grained calls
  const textAssets = await generateBirthdayText(employeeName, department, seniority);
  
  const videoPrompt = `Create a realistic cinematic birthday celebration video for ${employeeName}... (using other inputs)`;
  
  return {
    ...textAssets,
    videoPrompt,
    flyerBackgroundImagePrompt: `A beautiful birthday background for ${employeeName}, with balloons and confetti`,
    video_url: "" 
  };
}
